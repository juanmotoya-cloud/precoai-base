import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { correspondeAoProduto, converterPreco } from "./index.js";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const catalogo = JSON.parse(fs.readFileSync(path.resolve(__dirname, "..", "dados", "catalogo-sefaz.json"), "utf8"));
const arroz = catalogo.produtos.find((p) => p.id === "arroz");
const casos = [
  ["ARROZ BRANCO 500G", true],
  ["ARROZ BCO MANAUS 500G", true],
  ["ARROZ DE BROCOLIS", false],
  ["TEMP ARROZ FRANGO20G", false],
  ["TEMPERO PARA ARROZ E FRANGO 20G - UN", false],
  ["MINGAU ALCA FOODS 200G ARROZ", false],
  ["ALIM.P/CAES AD.DOG SHOW FGO/ARROZ - 1X85G", false],
  ["CF PORCAO DE ARROZ", false]
];
const bovina = catalogo.produtos.find((p) => p.id === "carne-bovina");
const frango = catalogo.produtos.find((p) => p.id === "frango");
const conserva = catalogo.produtos.find((p) => p.id === "carne-conserva");
const casosCarne = [
  [bovina, "ALCATRA BOVINA KG", true],
  [bovina, "COXAO MOLE BOVINO", true],
  [bovina, "CARNE BOVINA EM CONSERVA 320G", false],
  [bovina, "CORNED BEEF 300G", false],
  [frango, "PEITO DE FRANGO RESFRIADO KG", true],
  [frango, "FRANGO EM CONSERVA 300G", false],
  [conserva, "CARNE BOVINA EM CONSERVA 320G", true],
  [conserva, "CARNE ENLATADA 300G", true],
  [conserva, "CORNED BEEF 300G", true],
  [conserva, "ALCATRA BOVINA KG", false],
  [conserva, "COXAO MOLE BOVINO", false],
  [conserva, "PEITO DE FRANGO RESFRIADO KG", false],
  [conserva, "PATE DE CARNE 100G", false]
];
let falhas = 0;
for (const [produto, nome, esperado] of casosCarne) {
  const obtido = correspondeAoProduto(nome, produto).aceito;
  const ok = obtido === esperado;
  console.log(`${ok ? "OK" : "FALHOU"} | ${produto.id} | ${nome} | esperado=${esperado} obtido=${obtido}`);
  if (!ok) falhas++;
}
for (const [nome, esperado] of casos) {
  const obtido = correspondeAoProduto(nome, arroz).aceito;
  const ok = obtido === esperado;
  console.log(`${ok ? "OK" : "FALHOU"} | ${nome} | esperado=${esperado} obtido=${obtido}`);
  if (!ok) falhas++;
}
if (converterPreco("R$ 1.234,56") !== 1234.56) falhas++;
if (falhas) process.exit(1);
console.log(`\n${casos.length + casosCarne.length + 1} verificações aprovadas.`);
